import enum


class UserRole(str, enum.Enum):
    DEVELOPER = "DEVELOPER"
    TESTER = "TESTER"
    MANAGER = "MANAGER"
    ADMIN = "ADMIN"


class Severity(str, enum.Enum):
    CRITICAL = "CRITICAL"
    MAJOR = "MAJOR"
    MINOR = "MINOR"
    TRIVIAL = "TRIVIAL"


class Category(str, enum.Enum):
    # High urgency (weight 3)
    SECURITY = "Security"
    SECURITY_VULNERABILITY = "Security Vulnerability"
    DATABASE = "Database"
    # Medium urgency (weight 2)
    API = "API"
    BACKEND = "Backend"
    # Low urgency (weight 1)
    UI = "UI"
    UI_COLORS = "UI Colors"
    TYPOGRAPHY = "Typography"
    TYPOS = "Typos"


class Priority(str, enum.Enum):
    URGENT = "URGENT"
    HIGH = "HIGH"
    MEDIUM = "MEDIUM"
    LOW = "LOW"


class IssueType(str, enum.Enum):
    BUG = "BUG"
    FEATURE = "FEATURE"
    TASK = "TASK"
    IMPROVEMENT = "IMPROVEMENT"


class IssueStatus(str, enum.Enum):
    """
    Linear workflow required by spec:
    REPORTED -> TRIAGED -> IN_PROGRESS -> QA_VERIFICATION -> RESOLVED -> CLOSED
    Enforced centrally in services/status_workflow.py (added in Phase 4/9).
    """
    REPORTED = "REPORTED"
    TRIAGED = "TRIAGED"
    IN_PROGRESS = "IN_PROGRESS"
    QA_VERIFICATION = "QA_VERIFICATION"
    RESOLVED = "RESOLVED"
    CLOSED = "CLOSED"


class Environment(str, enum.Enum):
    PRODUCTION = "PRODUCTION"
    STAGING = "STAGING"
    DEVELOPMENT = "DEVELOPMENT"


class SprintStatus(str, enum.Enum):
    PLANNING = "PLANNING"
    ACTIVE = "ACTIVE"
    COMPLETED = "COMPLETED"
