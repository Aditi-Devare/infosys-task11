import uuid
from datetime import datetime

from sqlalchemy import (
    Column, String, Text, Integer, DateTime, ForeignKey, Enum as SAEnum, Index
)
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship

from app.database import Base
from app.models.enums import (
    Severity, Category, Priority, IssueType, IssueStatus, Environment
)


class Issue(Base):
    __tablename__ = "issues"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    display_id = Column(String(20), nullable=False, unique=True, index=True)  # e.g. "BUG-101"

    title = Column(String(300), nullable=False)
    description = Column(Text, nullable=True)

    severity = Column(SAEnum(Severity, name="issue_severity"), nullable=False, default=Severity.MINOR)
    category = Column(SAEnum(Category, name="issue_category"), nullable=False, default=Category.UI)
    priority_score = Column(Integer, nullable=False, default=0)  # severity_weight * category_weight
    priority = Column(SAEnum(Priority, name="issue_priority"), nullable=False, default=Priority.LOW)

    status = Column(SAEnum(IssueStatus, name="issue_status"), nullable=False, default=IssueStatus.REPORTED)
    issue_type = Column(SAEnum(IssueType, name="issue_type"), nullable=False, default=IssueType.BUG)
    environment = Column(SAEnum(Environment, name="issue_environment"), nullable=False, default=Environment.DEVELOPMENT)

    project_id = Column(UUID(as_uuid=True), ForeignKey("projects.id"), nullable=False)
    assignee_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    reporter_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=False)
    sprint_id = Column(UUID(as_uuid=True), ForeignKey("sprints.id"), nullable=True)

    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)
    resolved_at = Column(DateTime, nullable=True)

    project = relationship("Project", back_populates="issues")
    assignee = relationship("User", back_populates="assigned_issues", foreign_keys=[assignee_id])
    reporter = relationship("User", back_populates="reported_issues", foreign_keys=[reporter_id])
    sprint = relationship("Sprint", back_populates="issues")

    comments = relationship("Comment", back_populates="issue", cascade="all, delete-orphan")
    attachments = relationship("Attachment", back_populates="issue", cascade="all, delete-orphan")
    status_history = relationship("IssueStatusHistory", back_populates="issue", cascade="all, delete-orphan")
    audit_entries = relationship("AuditLog", back_populates="issue", cascade="all, delete-orphan")

    __table_args__ = (
        # Required composite indexes (Step 22 of the spec)
        Index("ix_issues_project_status", "project_id", "status"),
        Index("ix_issues_assignee_status", "assignee_id", "status"),
        Index("ix_issues_created_at", "created_at"),
    )


class IssueStatusHistory(Base):
    """Fine-grained record of every status transition (separate from the general AuditLog
    so the workflow validator has a fast, dedicated table to check 'current status' against)."""
    __tablename__ = "issue_status_history"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    issue_id = Column(UUID(as_uuid=True), ForeignKey("issues.id"), nullable=False, index=True)
    from_status = Column(SAEnum(IssueStatus, name="issue_status_from"), nullable=True)
    to_status = Column(SAEnum(IssueStatus, name="issue_status_to"), nullable=False)
    changed_by_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)

    issue = relationship("Issue", back_populates="status_history")
