"""
Import every model here so a single `from app.models import *` (or importing
this package at all, e.g. from main.py before create_all()) registers all
tables on Base.metadata. SQLAlchemy needs every model class imported at
least once before create_all()/migrations run, or it will silently skip
tables that were never loaded.
"""
from app.models.user import User  # noqa: F401
from app.models.project import Project, ProjectMember  # noqa: F401
from app.models.sprint import Sprint  # noqa: F401
from app.models.issue import Issue, IssueStatusHistory  # noqa: F401
from app.models.comment import Comment  # noqa: F401
from app.models.attachment import Attachment  # noqa: F401
from app.models.audit_log import AuditLog  # noqa: F401
from app.models.enums import (  # noqa: F401
    UserRole, Severity, Category, Priority, IssueType,
    IssueStatus, Environment, SprintStatus,
)
