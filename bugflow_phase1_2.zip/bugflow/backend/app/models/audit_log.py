import uuid
from datetime import datetime

from sqlalchemy import Column, String, DateTime, ForeignKey, Index
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship

from app.database import Base


class AuditLog(Base):
    """
    Records who changed what on an issue, and when. Covers status changes,
    assignee changes, priority changes, sprint changes, and automated
    Git-webhook-driven transitions (Step 8 / Step 13 of the spec).
    """
    __tablename__ = "audit_logs"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    issue_id = Column(UUID(as_uuid=True), ForeignKey("issues.id"), nullable=False, index=True)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)  # null = automated (e.g. webhook)

    action = Column(String(100), nullable=False)  # e.g. "STATUS_CHANGE", "ASSIGNEE_CHANGE", "AUTO_TRANSITION"
    old_value = Column(String(300), nullable=True)
    new_value = Column(String(300), nullable=True)

    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)

    issue = relationship("Issue", back_populates="audit_entries")
    user = relationship("User", back_populates="audit_entries")

    __table_args__ = (
        Index("ix_audit_logs_issue_created", "issue_id", "created_at"),
    )
