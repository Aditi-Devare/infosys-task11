from fastapi import APIRouter

from app.database import check_db_connection

router = APIRouter(tags=["health"])


@router.get("/health")
def health_check():
    db_ok = check_db_connection()
    return {
        "status": "healthy" if db_ok else "unhealthy",
        "database": "postgresql" if db_ok else "unavailable",
    }
