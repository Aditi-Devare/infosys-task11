"""
analytics router — placeholder for Phase 3 onward.
Not yet wired into main.py; will be filled in and included as each phase lands.
"""
from fastapi import APIRouter

router = APIRouter(prefix="/analytics", tags=["analytics"])
