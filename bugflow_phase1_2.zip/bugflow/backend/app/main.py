from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.config import settings
from app.database import Base, engine, check_db_connection
from app import models  # noqa: F401 - registers all tables on Base.metadata

app = FastAPI(
    title=settings.APP_NAME,
    description="BugFlow — Defect Tracking, Workflow, Sprint & Analytics API",
    version="0.1.0",
    docs_url="/docs",
    redoc_url="/redoc",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
def on_startup():
    # Phase 2 foundation: create tables if they don't exist yet.
    # A later phase can swap this for Alembic migrations without changing
    # anything else, since models/ and database.py are already migration-ready.
    Base.metadata.create_all(bind=engine)


@app.get("/health", tags=["health"])
def health_check():
    """
    Step 26: only report healthy if PostgreSQL is actually reachable.
    """
    db_ok = check_db_connection()
    return {
        "status": "healthy" if db_ok else "unhealthy",
        "database": "postgresql" if db_ok else "unavailable",
    }


# ---------------------------------------------------------------------------
# Routers are added phase by phase. Each router file already exists as a
# placeholder below and will be filled in during Phase 3 onward:
#   auth, issues, sprints, collaboration (comments/attachments),
#   webhooks, analytics, export
# ---------------------------------------------------------------------------
from app.routers import health as health_router  # noqa: E402

app.include_router(health_router.router, prefix=settings.API_V1_PREFIX)
