"""
Central application configuration.

Everything here is read from environment variables (with sane local-dev
defaults) so nothing sensitive is hardcoded in source. See .env.example
in the backend/ root for the full list of variables docker-compose and
local development expect.
"""
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    # ---- App ----
    APP_NAME: str = "BugFlow API"
    ENVIRONMENT: str = "development"  # development | production | test
    API_V1_PREFIX: str = "/api/v1"

    # ---- Database ----
    # Example: postgresql+psycopg2://bugflow:bugflow@db:5432/bugflow
    DATABASE_URL: str = (
        "postgresql+psycopg2://bugflow:bugflow@localhost:5432/bugflow"
    )
    DB_POOL_SIZE: int = 20
    DB_MAX_OVERFLOW: int = 10
    DB_POOL_PRE_PING: bool = True

    # ---- Auth ----
    JWT_SECRET_KEY: str = "CHANGE_ME_IN_PRODUCTION"
    JWT_ALGORITHM: str = "HS256"
    JWT_EXPIRE_MINUTES: int = 60 * 24  # 24h

    # ---- CORS ----
    # Comma-separated list of allowed origins for local dev; lock this down
    # to real origins in production via the CORS_ORIGINS env var.
    CORS_ORIGINS: str = "http://localhost:5500,http://127.0.0.1:5500,http://localhost:8000"

    # ---- Uploads ----
    UPLOAD_DIR: str = "uploads"
    ALLOWED_UPLOAD_EXTENSIONS: str = ".png,.jpg,.jpeg,.log"
    MAX_UPLOAD_SIZE_MB: int = 10

    # ---- Pagination ----
    DEFAULT_PAGE_LIMIT: int = 20
    MAX_PAGE_LIMIT: int = 100

    @property
    def cors_origins_list(self) -> list[str]:
        return [o.strip() for o in self.CORS_ORIGINS.split(",") if o.strip()]

    @property
    def allowed_upload_extensions_list(self) -> list[str]:
        return [e.strip().lower() for e in self.ALLOWED_UPLOAD_EXTENSIONS.split(",") if e.strip()]


settings = Settings()
