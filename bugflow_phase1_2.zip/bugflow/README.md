# BugFlow — Phase 1 & 2 (Project Audit + Backend/Database Foundation)

This delivers the first two phases of the full implementation plan:

- **Phase 1 — Audit:** confirmed in chat. The existing `frontend/BugFlow.html`
  is a single-file client app persisting to `localStorage`, with no server.
  It's copied here **unchanged** — no visual/design changes were made.
- **Phase 2 — Backend/database foundation:** a real FastAPI + PostgreSQL
  backend scaffold, with all required data models, connection pooling,
  env-based config, Docker, and a working `/health` check.

## What's actually functional right now

- `docker compose up --build` starts PostgreSQL + FastAPI.
- `GET /health` and `GET /api/v1/health` report `"healthy"` **only** when
  PostgreSQL is actually reachable (Step 26).
- On startup, all 8 tables are created: `users`, `projects`, `project_members`,
  `sprints`, `issues`, `issue_status_history`, `comments`, `attachments`,
  `audit_logs` — matching the fields specified in Steps 2–2 of the spec,
  including the required composite indexes on `issues`
  (`project_id, status`), (`assignee_id, status`), (`created_at`).
- `/docs` and `/redoc` (Swagger/ReDoc) work automatically via FastAPI.
- SQLAlchemy engine is configured with `pool_size=20, max_overflow=10,
  pool_pre_ping=True`, and `DATABASE_URL` / `JWT_SECRET_KEY` are read from
  environment variables only — see `backend/.env.example`.

## What's intentionally NOT here yet (later phases)

No business logic yet: no auth endpoints, no issue CRUD, no priority
calculator, no developer matcher, no comments/attachments API, no sprint
APIs, no Git webhook, no analytics/Plotly, no PDF/CSV export, no pagination
wiring, no frontend integration, and no tests. Router files for all of
these (`auth.py`, `issues.py`, `sprints.py`, `collaboration.py`,
`webhooks.py`, `analytics.py`, `export.py`) exist as empty placeholders
under `backend/app/routers/` so the structure is visible, but they are not
yet included in `main.py` and contain no endpoints. Building these is
Phase 3 onward.

## Running it locally (without Docker)

```bash
cd backend
python -m venv venv && source venv/bin/activate
pip install -r requirements.txt
cp .env.example .env   # edit DATABASE_URL to point at a local Postgres
uvicorn app.main:app --reload
```

## Running it with Docker

```bash
docker compose up --build
# API:      http://localhost:8000
# Health:   http://localhost:8000/health
# Docs:     http://localhost:8000/docs
```

## Project layout

```
backend/
  app/
    main.py            FastAPI app, CORS, startup table creation, /health
    config.py           env-driven Settings (DB, JWT, CORS, uploads, pagination)
    database.py         SQLAlchemy engine w/ pooling, get_db() dependency, check_db_connection()
    models/              User, Project, ProjectMember, Sprint, Issue,
                          IssueStatusHistory, Comment, Attachment, AuditLog, enums
    routers/              health.py (live) + auth/issues/sprints/collaboration/
                          webhooks/analytics/export (placeholders, Phase 3+)
    schemas/, services/, utils/   empty, populated from Phase 3 onward
  tests/                empty, populated in Phase 13
  requirements.txt
  Dockerfile
  .env.example
docker-compose.yml
frontend/
  BugFlow.html          your original file, copied unmodified
```

## Note on the status workflow

`IssueStatus` in `models/enums.py` uses the workflow you specified —
`REPORTED → TRIAGED → IN_PROGRESS → QA_VERIFICATION → RESOLVED → CLOSED` —
which differs from the current frontend's states (`OPEN, ASSIGNED,
IN_REVIEW`, etc.). The frontend hasn't been touched yet, so this mismatch
is invisible for now; it becomes relevant in Phase 12 (frontend
integration), where the issue badges/dropdowns get updated to the new
states with two small additive CSS classes, not a redesign. Flag now if
you'd rather I reconcile it differently.

## Next: Phase 3

Priority calculator + developer matcher services (Steps 3–4), plus the
`issues` router (create/list/get/update) as the first real endpoints.
